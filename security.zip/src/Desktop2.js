import { useCallback } from "react";

import "./desktop2.css";
import Futter from "./Futter";
const Desktop2 = () => {
 

  const onCONTACTTextClick = useCallback(() => {
    // Please sync "Desktop - 6" to the project
  }, []);

  const onTRAININGTextClick = useCallback(() => {
    // Please sync "Desktop - 6" to the project
  }, []);

  const onHOMETextClick = useCallback(() => {
    ("/");
  }, []);

  const onABOUTUSTextClick = useCallback(() => {
    // Please sync "Desktop - 6" to the project
  }, []);

  const onTRAININGText1Click = useCallback(() => {
    // Please sync "Desktop - 6" to the project
  }, []);

  const onCONTACTText1Click = useCallback(() => {
    // Please sync "Desktop - 6" to the project
  }, []);

  return (
    
    <div className="desktop-2">
      {/* <div className="rectangle-div29hi" />
      <img className="vector-icon8hi" alt="" src="../picture/Vector 1 (1).png" /> */}
     {/* <div className="contact-div5hi" onClick={onCONTACTTextClick}>
        CONTACT
      </div>
      <div className="line-div8hi" />
      <div className="training-div5hi" onClick={onTRAININGTextClick}>
        TRAINING
  </div>*/}
      {/* <img className="nja-logo-12hi" alt="" src="../picture/nja logo 1.png" /> */}
      <img className="rectangle-icon17hi" alt="" src="../picture/Rectangle 2.png" />
      {/* <div className="rectangle-div30hi" /> */}
      <div className="our-company-ms-nja-security-p1hi">
        Our company M/S NJA SECURITY PRIVATE LIMITED will pioneer the Industry
        Services and will set standrds by way of Caliber of personnel, uality of
        services, Commitment to training and development the high degree of
        professionalism.
      </div>
      <div className="with-the-need-based-approch-t1hi">
        With the need based approch, the company will be in the field of
        providing security for properties, Industries Corporate men and
        materials against thef, pilferage, sabotage, all kinds of man made
        threats, strikes and labour unrest. I will pay my utmost attention in
        assisting the management by way of extra security measures and staff. I
        will also render free advice to clients on all security matters.
      </div>
      <div className="welcome-to-nja-security-pvt-l1hi">
        WELCOME TO NJA SECURITY PVT. LTD.
      </div>
      {/*<div className="home-div4hi" onClick={onHOMETextClick}>
        HOME
      </div>
      <div className="about-us-div4hi" onClick={onABOUTUSTextClick}>
        ABOUT US
</div>*/}
      <div className="line-div9hi" />
      <div className="line-div10hi" />
      <div className="line-div11hi" />
      <div className="members-of-management-will-behi">
        Members of Management will be available for emergency at any time.
      </div>
      <div className="guardingindustrial-security1hi">
        <ul className="guardingindustrial-security2hi">
          <li className="transportation-of-cashvaluablhi">
            Guarding/Industrial Security (Manpower)
          </li>
          <li className="transportation-of-cashvaluablhi">
            Transportation of Cash/Valuables.
          </li>
          <li className="transportation-of-cashvaluablhi">
            Security of Ware Houses/Departmental Stores.
          </li>
          <li className="transportation-of-cashvaluablhi">Night Patrol</li>
          <li className="transportation-of-cashvaluabl">
            Electronic Security and Security Equipment
          </li>
          <li className="transportation-of-cashvaluablhi">
            Installation and maintenance of security and fire safety systems.
          </li>
          <li className="transportation-of-cashvaluablhi">
            Private Investigation
          </li>
          <li className="transportation-of-cashvaluablhi">
            Security audit/consultancy
          </li>
          <li className="transportation-of-cashvaluablhi">
            Training of Security Staff
          </li>
          <li className="transportation-of-cashvaluablhi">
            Business Executive Protection
          </li>
          <li>Events Security</li>
        </ul>
      </div>
      <div className="services-planned-divhi">Services Planned</div>

      <div style={{position: 'relative', top: '1022px'}}>
      {/* <Futter/> */}
      </div>
      {/* <div className="group-div20hi">
        <div className="rectangle-div31hi" />
        <div className="home-div5hi">HOME</div>
        <img className="nja-logo-22hi" alt="" src="../picture/nja logo 2.png" />
        <b className="usefull-link-b2hi">USEFULL LINK</b>
        <b className="security-services-b2">SECURITY SERVICES</b>
        <b className="contact-us-b2hi">CONTACT US</b>
        <div className="security-services-div5hi">SECURITY SERVICES</div>
        <div className="about-us-div5hi">ABOUT US</div>
        <div className="training-div6hi" onClick={onTRAININGText1Click}>
          TRAINING
        </div>
        <div className="contact-div6hi" onClick={onCONTACTText1Click}>
          CONTACT
        </div>
        <div className="gf-gali-no-19-bhagwati-ga3hi">
          <p className="gf-gali3hi">18, G.F., Gali No. 19, Bhagwati</p>
          <p className="gf-gali3hi">Garden Extn., Uttam Nagar,</p>
          <p className="new-delhi-110059-p3hi">New Delhi-110059</p>
        </div>
        <div className="njasecurgmailcom-div3hi">njasecur@gmail.com</div>
        <div className="div6hi">99711-87836</div>
        <div className="div7hi">87504-02774</div>
        <img className="group-icon9hi" alt="" src="../picture/Group 7.png" />
        <img className="group-icon10hi" alt="" src="../picture/Group 8.png" />
        <img className="group-icon11hi" alt="" src="../picture/Group 9.png" />
        <div className="guardingindustrial-security-div2hi">
          Guarding/Industrial Security
        </div>
        <div className="transportation-of-cash3hi">Transportation of Cash</div>
        <div className="security-of-ware-houses2hi">Security of Ware Houses</div>
        <div className="night-patrol-div3hi">Night Patrol</div>
        <div className="electronic-security-div2hi">Electronic Security</div>
        <div className="security-equipment-div2hi">Security Equipment</div>
        <div className="fire-safety-systems2hi">Fire safety systems.</div>
        <div className="private-investigation-div3hi">Private Investigation</div>
        <div className="security-auditconsultancy-div3hi">
          Security audit/consultancy
        </div>
        <div className="training-of-security-staff3hi">
          Training of Security Staff
        </div>
        <div className="business-executive-protection4hi">
          Business Executive Protection
        </div>
        <div className="events-security-div3hi">Events Security</div>
        <div className="nja-security-pvt-ltd3hi">
          <p className="gf-gali3hi">{`NJA SECURITY `}</p>
          <p className="new-delhi-110059-p3hi">PVT. LTD</p>
        </div>
        <img className="arrow-icon34" alt="" src="..picture/Arrow 1.png" />
        <img className="arrow-icon35hi" alt="" src="..picture/Arrow 1.png" />
        <img className="arrow-icon36hi" alt="" src="..picture/Arrow 1.png" />
        <img className="arrow-icon37" alt="" src="..picture/Arrow 1.png" />
        <img className="arrow-icon38hi" alt="" src="..picture/Arrow 1.png" />
        <img className="arrow-icon39hi" alt="" src="..picture/Arrow 1.png" />
        <img className="arrow-icon40hi" alt="" src="..picture/Arrow 1.png" />
        <img className="arrow-icon41hi" alt="" src="..picture/Arrow 1.png" />
        <img className="arrow-icon42hi" alt="" src="..picture/Arrow 1.png" />
        <img className="arrow-icon43" alt="" src="..picture/Arrow 1.png" />
        <img className="arrow-icon44hi" alt="" src="..picture/Arrow 1.png" />
        <img className="arrow-icon45hi" alt="" src="..picture/Arrow 1.png" />
        <img className="arrow-icon46hi" alt="" src="..picture/Arrow 1.png" />
        <img className="arrow-icon47hi" alt="" src="..picture/Arrow 1.png" />
        <img className="arrow-icon48hi" alt="" src="..picture/Arrow 1.png" />
        <img className="arrow-icon49hi" alt="" src="..picture/Arrow 1.png" />
        <img className="arrow-icon50hi" alt="" src="..picture/Arrow 1.png" />
      </div> */}
      {/* <div className="group-div21hi"> */}
        {/* <div className="security-services-div6hi">SECURITY SERVICES</div> */}
        {/* <img className="vector-icon9hi" alt="" src="../picture/Vector (1).png" /> */}
      {/* </div> */}

      
    </div>

  );
};

export default Desktop2;







